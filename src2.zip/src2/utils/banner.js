const banner = [
  {
    id: '1',
    title: 'Bingung Cari Material Bangunan?',
    decs: 'Temukan material yang kamu butuhkan',
    image: require('../assets/Images/img1.jpg'),
    // image:
    //   'https://as2.ftcdn.net/v2/jpg/02/12/01/85/1000_F_212018523_kpDGKAJdl77cB9o1jsBZ7EOG9LrQ6cwh.jpg',
  },
  {
    id: '2',
    title: 'Kualitas Terbaik, Harga Kompetitif',
    decs: 'Manajemen material kualitas baik dengan harga kompetitif',
    image: require('../assets/Images/img2.jpg'),
  },
];

export default banner;
