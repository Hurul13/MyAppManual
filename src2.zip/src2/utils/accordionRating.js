const accordionRating = [
  {
    id: '0',
    title: 'Review',
    nameUser: 'Shabila Gadis Halida',
    imageUser: require('../assets/Images/user1.jpg'),
    review: 'Tidak ada komen',
    imageReview: require('../assets/Images/pasir.jpg'),
    time: '30-03-2023 10.40',
  },
  {
    id: '1',
    title: 'Review',
    nameUser: 'Blaa Blaa',
    imageUser: require('../assets/Images/user1.jpg'),
    review: 'Mantappp',
    imageReview: require('../assets/Images/pasir.jpg'),
    time: '30-03-2023 10.40',
  },
  {
    id: '2',
    title: 'Review',
    nameUser: 'Lorem Ipsum',
    imageUser: require('../assets/Images/user1.jpg'),
    review: 'Sesuai deskripsi',
    imageReview: require('../assets/Images/pasir.jpg'),
    time: '30-03-2023 10.40',
  },
];

export default accordionRating;
