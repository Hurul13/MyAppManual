const riwayatTransaksi = [
  {
    id: 1,
    gambar: require('../assets/Images/batu.jpg'),
    nomorTransaksi: 'TRsdfghjkfghX001',
    totalHarga: 100000,
    tanggal: '2023-05-28',
    status: 'Belum Bayar',
  },
  {
    id: 2,
    gambar: require('../assets/Images/besi.jpg'),
    nomorTransaksi: 'TRX002',
    totalHarga: 150000,
    tanggal: '2023-05-27',
    status: 'Dikirim',
  },
  {
    id: 2,
    gambar: require('../assets/Images/genteng.jpg'),
    nomorTransaksi: 'TRsdfghjjjjjX003',
    totalHarga: 150000,
    tanggal: '2023-05-27',
    status: 'Dikemas',
  },
  {
    id: 2,
    gambar: require('../assets/Images/semen.jpg'),
    nomorTransaksi: 'TRdfghjkX004',
    totalHarga: 150000,
    tanggal: '2023-05-27',
    status: 'Selesai',
  },
];

export default riwayatTransaksi;
