// hotspot hp
export const url = 'http://192.168.43.203:8000/homeii/web/api/v1/';

// wifi rumah
// export const url = 'http://192.168.1.3:8000/homeii/web/api/v1/';

// wifi kampus
// export const url = 'http://10.251.137.164:8000/homeii/web/api/v1/';

// wifi tongkrongan
// export const url = 'http://10.251.12.117:8000/homeii/web/api/v1/';

// wifi kos sby
// export const url = 'http://192.168.120.203:8000/homeii/web/api/v1/';
