import { url } from '../../utils/url';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { WARNA_BLACK } from '../../utils/constant';
// import React, {useEffect, useState} from 'react';
// import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';

// const HistoryPage = () => {
//   const [invoices, setInvoices] = useState([]);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const userId = await AsyncStorage.getItem('user_id');
//         const token = await AsyncStorage.getItem('token');

//         const response = await fetch(
//           `${url}invoice/view-order-by-user-id?user_id=${userId}`,
//           {
//             headers: {
//               Authorization: `Bearer ${token}`,
//             },
//           },
//         );

//         if (response.ok) {
//           const data = await response.json();
//           setInvoices(data);
//           console.log('Data invoices:', data);
//         } else {
//           console.log('Error fetching data:', response.status);
//         }
//       } catch (error) {
//         console.log('Error:', error);
//       }
//     };

//     fetchData();
//   }, []);

//   const handleDetailPress = invoiceCode => {
//     console.log('Navigating to detail page:', invoiceCode);
//     // Tambahkan logika untuk navigasi ke halaman rincian pesanan menggunakan invoiceCode
//   };

//   return (
//     <View style={styles.container}>
//       {invoices.map(invoice => (
//         <TouchableOpacity
//           key={invoice.invoice_code}
//           style={styles.card}
//           onPress={() => handleDetailPress(invoice.invoice_code)}>
//           <Text>Invoice Code: {invoice.invoice_code}</Text>
//           <Text>Status: {invoice.status}</Text>
//           <TouchableOpacity
//             onPress={() => handleDetailPress(invoice.invoice_code)}>
//             <Text>Go to Detail</Text>
//           </TouchableOpacity>
//         </TouchableOpacity>
//       ))}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 16,
//     backgroundColor: '#fff',
//   },
//   card: {
//     borderWidth: 1,
//     borderColor: '#ccc',
//     borderRadius: 4,
//     padding: 12,
//     marginBottom: 12,
//   },
// });

// export default HistoryPage;

//

import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const HistoryPage = () => {
  const [orders, setOrders] = useState([]);
  const [selectedOrderType, setSelectedOrderType] = useState('unpaid');
  const [userId, setUserId] = useState('');

  useEffect(() => {
    // Mendapatkan user_id dari AsyncStorage
    AsyncStorage.getItem('user_id')
      .then(value => {
        setUserId(value);
        fetchOrders(value, selectedOrderType); // Mengambil pesanan saat pertama kali halaman dimuat
      })
      .catch(error => console.log(error));
  }, []);

  const fetchOrders = async (userId, orderType) => {
    try {
      const token = await AsyncStorage.getItem('token');
      const response = await fetch(
        `${url}invoice/view-order-by-user-id?user_id=${userId}&orderType=${orderType}`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );
      const data = await response.json();
      setOrders(data.data);
      console.log(`Fetched ${orderType} orders:`, data);
    } catch (error) {
      console.log(error);
    }
  };

  const handleOrderTypeChange = orderType => {
    setSelectedOrderType(orderType);
    fetchOrders(userId, orderType);
  };

  const renderOrderStatusColor = status => {
    // Mengembalikan warna teks berdasarkan status pesanan
    if (status === 'unpaid') return 'yellow';
    if (status === 'shipped') return 'green';
    if (status === 'cancelled') return 'red';
    return 'black';
  };

  return (
    <View style={styles.container}>
      <View style={styles.orderTypes}>
        <TouchableOpacity
          style={[
            styles.orderTypeButton,
            selectedOrderType === 'unpaid' && styles.selectedOrderType,
          ]}
          onPress={() => handleOrderTypeChange('unpaid')}>
          <Text style={styles.orderTypeButtonText}>Unpaid Orders</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.orderTypeButton,
            selectedOrderType === 'shipped' && styles.selectedOrderType,
          ]}
          onPress={() => handleOrderTypeChange('shipped')}>
          <Text style={styles.orderTypeButtonText}>Paid Orders</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.orderTypeButton,
            selectedOrderType === 'cancelled' && styles.selectedOrderType,
          ]}
          onPress={() => handleOrderTypeChange('cancelled')}>
          <Text style={styles.orderTypeButtonText}>Cancel Orders</Text>
        </TouchableOpacity>
      </View>
      {orders &&
        orders.map(order => (
          <TouchableOpacity
            key={order.invoice_code}
            style={[
              styles.card,
              { backgroundColor: renderOrderStatusColor(order.status) },
            ]}
            onPress={() =>
              console.log(`Navigating to order details: ${order.invoice_code}`)
            }>
            <Text style={styles.invoiceCode}>{order.invoice_code}</Text>
            <Text style={styles.status}>{order.status}</Text>
          </TouchableOpacity>
        ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  orderTypes: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  orderTypeButton: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 4,
    paddingVertical: 8,
    marginRight: 8,
  },
  selectedOrderType: {
    backgroundColor: 'gray',
  },
  orderTypeButtonText: {
    fontWeight: 'bold',
    color: 'black',
  },
  card: {
    marginBottom: 8,
    padding: 16,
    borderRadius: 4,
  },
  invoiceCode: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  status: {
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default HistoryPage;
