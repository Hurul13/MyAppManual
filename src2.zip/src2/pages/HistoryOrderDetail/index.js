import AsyncStorage from '@react-native-async-storage/async-storage';
import { url } from '../../utils/url';
import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import { WARNA_BLACK } from '../../utils/constant';

const HistoryOrderDetail = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    getOrdersByInvoice();
  }, []);

  const getOrdersByInvoice = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const user_id = await AsyncStorage.getItem('user_id');
      const response = await fetch(
        `${url}invoice/view-order-by-user-id?user_id=${user_id}`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = await response.json();
      setOrders(data.data.orders);
      console.log('data get user_id:', data.data);
    } catch (error) {
      console.log(error);
    }
  };

  const renderOrderCards = () => {
    const renderedCards = [];
    const addedInvoiceIds = new Set();

    orders.forEach((order) => {
      const { invoice, order_product, supplier_barang } = order;
      const { invoice_code, status } = invoice;
      const { jumlah, harga_satuan, subtotal } = order_product;
      const { gambar } = supplier_barang;

      if (!addedInvoiceIds.has(invoice_code)) {
        renderedCards.push(
          <TouchableOpacity
            key={invoice_code}
            onPress={() => handleCardPress(invoice_code)}
            style={{
              backgroundColor: getCardColor(status),
              padding: 10,
              margin: 10,
              borderRadius: 5,
            }}
          >
            <Image source={{ uri: gambar }} style={{ width: 50, height: 50 }} />
            <Text style={{ color: WARNA_BLACK }}>{invoice_code}</Text>
            <Text style={{ color: WARNA_BLACK }}>Status: {getStatusText(status)}</Text>
            <Text style={{ color: WARNA_BLACK }} >Jumlah: {jumlah}</Text>
            <Text style={{ color: WARNA_BLACK }}>Harga Satuan: {harga_satuan}</Text>
            <Text style={{ color: WARNA_BLACK }}>Subtotal: {subtotal}</Text>
            <IconMaterial name="eye" size={20} color={WARNA_BLACK} />
          </TouchableOpacity>
        );

        addedInvoiceIds.add(invoice_code);
      }
    });

    return renderedCards;
  };

  const getCardColor = (status) => {
    if (status === 'belum_bayar') {
      return 'yellow';
    } else if (status === 'dikemas_dikirim') {
      return 'green';
    } else if (status === 'dibatalkan') {
      return 'red';
    }
    return 'white';
  };

  const getStatusText = (status) => {
    if (status === 'belum_bayar') {
      return 'Belum Bayar';
    } else if (status === 'dikemas_dikirim') {
      return 'Dikemas, Dikirim';
    } else if (status === 'dibatalkan') {
      return 'Dibatalkan';
    }
    return 'Unknown';
  };

  const handleCardPress = (invoice_code) => {
    // Handle card press event based on the invoice code
    // Use navigation or any other logic to navigate to the respective detail page
    if (invoice_code) {
      if (invoice_code === 'belum_bayar') {
        // Navigate to HistoryOrderDetailBelumBayar with invoice_code
        navigation.navigate('HistoryOrderDetailBelumBayar', { invoice_id: invoice_code.invoice.id });
      } else if (invoice_code === 'dikemas_dikirim') {
        // Navigate to HistoryOrderDetailSudahBayar with invoice_code
        navigation.navigate('HistoryOrderDetailSudahBayar', { invoice_id: invoice_code.invoice.id });
      } else if (invoice_code === 'dibatalkan') {
        // Navigate to HistoryOrderDetailDibatalkan with invoice_code
        navigation.navigate('HistoryOrderDetailDibatalkan', { invoice_id: invoice_code.invoice.id });
      }
    }
  };

  return (
    <ScrollView>
      {renderOrderCards()}
    </ScrollView>
  );
};


export default HistoryOrderDetail;