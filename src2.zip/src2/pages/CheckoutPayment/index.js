import React, { useEffect, useState } from 'react';
import { Text, View, Image, TouchableOpacity, ToastAndroid } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { url } from '../../utils/url';
import { WARNA_BLACK, WARNA_BLUE, WARNA_RED, WARNA_UTAMA } from '../../utils/constant';
import { responsiveHeight } from 'react-native-responsive-dimensions';

const HistoryOrderDetailSudahBayar = ({ navigation, route }) => {
  const navigateTo = async page => {
    navigation.navigate(page);
  };
  const { invoice_id } = route.params;
  const [orderData, setOrderData] = useState(null);

  useEffect(() => {
    fetchOrderData();
  }, []);

  const fetchOrderData = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const response = await fetch(`${url}order-product/view-order-by-invoice?invoice_id=${invoice_id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await response.json();
      setOrderData(data.data);
      console.log('data get invoice_id: ', data.data);
    } catch (error) {
      console.log(error);
    }
  };

  // const onRefresh = async () => {
  //   setRefreshing(true);
  //   await handleAddAddress();
  //   setRefreshing(false);
  // };

  const handleCancel = async () => {
    try {
      const token = await AsyncStorage.getItem('token'); // Get the token from AsyncStorage

      const response = await fetch(
        `${url}order-product/cancel-order?invoice_id=${invoice_id}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        },
      );

      const data = await response.json();
      console.log(data);
      ToastAndroid.show('Berhasil batalkan', ToastAndroid.SHORT);
      navigation.navigate('HistoryOrder');
    } catch (error) {
      console.error(error);
    }
  };

  if (!orderData) {
    return (
      <View>
        <Text>Loading...</Text>
      </View>
    );
  }

  const {
    // user_address_id,
    order,
  } = orderData;
  // console.log('user_address_id: ', user_address_id)

  // const renderAddress = () => {
  //   if (user_address_id === user_address_id) {
  //     // Render the address details
  //     return (
  //       <View>
  //         {/* Display the address details */}
  //         <Text>Nama Penerima: {nama_penerima}</Text>
  //         <Text>Nomor Penerima: {nomor_penerima}</Text>
  //         <Text>Alamat Penerima: {alamat_penerima}</Text>
  //         <Text>Provinsi ID: {provinsi_id}</Text>
  //         <Text>Kota ID: {kota_id}</Text>
  //         <Text>Kecamatan ID: {kecamatan_id}</Text>
  //         <Text>Desa ID: {desa_id}</Text>
  //         <Text>Kode Pos: {kode_pos}</Text>
  //       </View>
  //     );
  //   } else {
  //     return null; // Render nothing if user_address_id is not 0
  //   }
  // };

  return (
    <View
    // style={{ backgroundColor: WARNA_BLACK }}
    >
      {/* Render the address details */}
      {/* {renderAddress()} */}

      {/* Render the order details */}
      {order.map((item, index) => (
        <View key={index} style={styles.card}>
          <Image source={{ uri: item.gambar }} style={styles.productImage} />
          <View style={styles.productInfo}>
            <Text style={styles.productName}>{item.nama_barang}</Text>
            <Text style={styles.productPrice}>Harga Satuan: Rp {item.harga_satuan}</Text>
            <Text style={styles.productQuantity}>Jumlah: {item.jumlah}</Text>
            <Text style={styles.productSubtotal}>Subtotal: Rp {item.subtotal * item.jumlah}</Text>
          </View>
        </View>
      ))}
      {/* Render the payment and cancel buttons */}
      <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
        <TouchableOpacity onPress={handleCancel}>
          <Text style={{ backgroundColor: WARNA_RED, padding: responsiveHeight(2), borderRadius: 8, marginVertical: responsiveHeight(1), paddingHorizontal: responsiveHeight(10) }}>Batalkan</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};
export default HistoryOrderDetailSudahBayar;

const styles = {
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: WARNA_UTAMA,
  },
  iconBack: {
    color: WARNA_BLACK,
    marginRight: 10,
  },
  title: {
    fontSize: 20,
    color: WARNA_BLACK,
    fontWeight: 'bold',
  },
  content: {
    padding: 20,
  },
  subtitle: {
    fontSize: 13,
    fontWeight: 'bold',
    color: WARNA_BLACK,
    marginBottom: 10,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  icon: {
    marginRight: 10,
  },
  addressInfo: {
    flex: 1,
  },
  addressTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  addressText: {
    fontSize: 14,
    color: '#555',
  },
  productImage: {
    width: 80,
    height: 80,
    marginRight: 10,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#555',
    marginBottom: 5,
  },
  productPrice: {
    fontSize: 14,
    color: '#555',
    marginBottom: 5,
  },
  productQuantity: {
    fontSize: 14,
    color: '#555',
    marginBottom: 5,
  },
  productSubtotal: {
    fontSize: 14,
    color: '#555',
    fontWeight: 'bold',
  },
  totalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    color: '#555',
    marginTop: 20,
  },
  totalLabel: {
    flex: 1,
    fontSize: 18,
    color: '#555',
    fontWeight: 'bold',
  },
  totalPrice: {
    fontSize: 18,
    color: '#555',
    fontWeight: 'bold',
  },
  checkoutButton: {
    backgroundColor: WARNA_UTAMA,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 20,
    alignItems: 'center',
  },
  checkoutButtonText: {
    color: WARNA_BLACK,
    fontSize: 16,
    fontWeight: 'bold',
  },
};