import React, { Component, useState } from 'react';
import { View, Alert, Text, ToastAndroid, RefreshControl, ScrollView } from 'react-native';
import TouchID from 'react-native-touch-id';
import { WARNA_BLACK, WARNA_UTAMA } from '../../utils/constant';
import { responsiveFontSize, responsiveHeight } from 'react-native-responsive-dimensions';

const CheckoutShipping = () => {
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = () => {
    setRefreshing(true);
    // Perform your refresh logic here

    // Simulating a delay of 1 second before stopping the refresh animation
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const verifyFingerprint = () => {
    const optionalConfigObject = {
      title: 'Authentication Required', // Android
      imageColor: '#e00606', // Android
      imageErrorColor: '#ff0000', // Android
      sensorDescription: 'Touch sensor', // Android
      sensorErrorDescription: 'Failed', // Android
      cancelText: 'Cancel', // Android
      unifiedErrors: false, // use unified error messages (default false)
      fallbackLabel: 'Show Passcode', // iOS (if empty, then label is hidden)
      passcodeFallback: false, // iOS - allows the device to fall back to using the passcode, if faceid/touch is not available. this does not mean that if touchid/faceid fails the first few times it will revert to passcode, rather that if the former are not enrolled, then it will use the passcode.
    };
    TouchID.authenticate('Verifikasi sidik jari', optionalConfigObject
    )
      .then((success) => {
        console.log('Sidik jari terverifikasi')
        Alert.alert('Berhasil', 'Sidik jari terverifikasi');
        ToastAndroid.show('Sidik jari terverifikasi', ToastAndroid.SHORT);
      })
      .catch((error) => {
        console.log('Sidik jari gagal diverifikasi')
        Alert.alert('Gagal', 'Sidik jari gagal diverifikasi');
        ToastAndroid.show('Sidik jari gagal diverifikasi', ToastAndroid.SHORT);
      });
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center' }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <Text style={{ color: WARNA_BLACK, backgroundColor: WARNA_UTAMA, padding: responsiveHeight(2), fontWeight: '800', fontSize: responsiveFontSize(2), borderRadius: 10 }} onPress={verifyFingerprint}>
          Verifikasi Sidik Jari
        </Text>
      </ScrollView>
    </View>
  );
};

export default CheckoutShipping;
