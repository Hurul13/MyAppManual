export const emailKey = 'storeEmail';
export const pinKey = 'storePin';
