export const Imagess = {
  productImageList: [
    require('../assets/Images/batu.jpg'),
    require('../assets/Images/besi.jpg'),
    require('../assets/Images/genteng.jpg'),
  ],
};
