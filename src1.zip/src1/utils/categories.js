const categories = [
  {id: '1', name: 'KERAMIK', image: require('../assets/Images/keramik.jpg')},
  {id: '2', name: 'GENTENG', image: require('../assets/Images/genteng.jpg')},
  {id: '3', name: 'PASIR', image: require('../assets/Images/pasir.jpg')},
  {id: '4', name: 'SEMEN', image: require('../assets/Images/semen.jpg')},
  {id: '5', name: 'BATU', image: require('../assets/Images/batu.jpg')},
  {id: '6', name: 'BESI', image: require('../assets/Images/besi.jpg')},
];

export default categories;
