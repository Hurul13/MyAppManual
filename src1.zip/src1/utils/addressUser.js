const addressUser = [
  {
    id: '1',
    label: 'Enter Country',
    type: 'text',
    icon: '',
  },
  {
    id: '2',
    label: 'Enter City',
    type: 'text',
    icon: '',
  },
  {
    id: '3',
    label: 'Enter Postal Code',
    type: 'numeric',
    icon: '',
  },
  {
    id: '4',
    label: 'Enter Address',
    type: 'text',
    icon: '',
  },
];

export default addressUser;
