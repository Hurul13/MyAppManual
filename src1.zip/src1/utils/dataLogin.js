const dataLogin = [
  {
    id: '1',
    label: 'Nama',
    type: 'text',
    icon: '',
  },
  {
    id: '2',
    label: 'Email',
    type: 'text',
    icon: '',
  },
  {
    id: '3',
    label: 'Telepon',
    type: 'numeric',
    icon: '',
  },
  {
    id: '4',
    label: 'Username',
    type: 'text',
    icon: '',
  },
  {
    id: '5',
    label: 'Password',
    type: 'password',
    icon: '',
  },
  {
    id: '6',
    label: 'Konfirmasi Password',
    type: 'password',
    icon: '',
  },
];

export default dataLogin;
