const editProfile = [
  {
    id: '1',
    label: 'Password Lama',
    type: 'text',
    placeholder: 'Masukkan password lama ...',
    text: 'lorem123',
  },
  {
    id: '2',
    label: 'Password Baru',
    type: 'text',
    placeholder: 'Masukkan password baru ...',
    text: 'lorem12345',
  },
  {
    id: '3',
    label: ' Konfirmasi Password',
    type: 'text',
    placeholder: 'Masukkan konfirmasi password ...',
    text: 'lorem12345',
  },
];

export default editProfile;
